import React, { useState } from 'react'
import Form from 'react-bootstrap/Form'
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import Button from 'react-bootstrap/Button'
import 'react-toastify/dist/ReactToastify.css';
import StudentNavbar from '../StudentNavbar';
import { useLocalState } from '../../../util/useLocalStorage';

const EditStudentProfile = () => {

    const [jwt, setJwt] = useLocalState("", "jwt");
    const [userEmail, setUserEmail] = useLocalState("", "userEmail");

    const [name, setName] = useState("");
    const [phoneNo, setPhoneNo] = useState("");

    function sendUpdateRequest () {
        if(name === "" || phoneNo === "") {
            alert("Fields can't be empty");
            return;
        }
        fetch(`/student/editProfile/${userEmail}?newStudentName=${name}&newPhoneNo=${phoneNo}`,{
            method:"PUT",
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${jwt}`
            }, 
        })
        .then((response) => {
          if (response.status === 200)
            return Promise.all([response.status, response.text()]);
            else return Promise.reject("Invalid Update Details attempt");
        })
        .then(([status, body]) => {
            alert(body);
            window.location.href = "/studentDashboard";
        })
        .catch((message) => {
          alert(message);
        });
    }

     return (
        <div style={{minHeight:"85vh"}}>
            <StudentNavbar />
            
  
            <div className="col-md-6 offset-md-3 border rounded p-4 mt-3 mb-1 shadow">
                <section className='d-flex justify-content-between'>
                    <div className="left_data mt-2 p-3" style={{ width: "100%" }}>
                    <center> <h3 className='text-center col-lg-6 mb-5 mt-2'>Edit Profile</h3>
</center>   
                        <Form >
                        <Form.Group as={Row} className="mb-3" controlId="formPlaintextName">
                            <Form.Label column sm="2">
                            Name
                            </Form.Label>
                            <Col sm="10">
                            <Form.Control 
                                type="name" 
                                placeholder="Enter Your Name"
                                value={name} 
                                onChange = {(e) => setName(e.target.value)} 
                            />
                            </Col>
                         </Form.Group>

                         <Form.Group as={Row} className="mb-5" controlId="formPlaintextphone">
                            <Form.Label column sm="2">
                         Phone
                            </Form.Label>
                            <Col sm="10">
                            <Form.Control 
                                type="phone" 
                                placeholder="Enter Your Phone No." 
                                value={phoneNo} 
                                onChange = {(e) => setPhoneNo(e.target.value)}
                            />
                            </Col>
                         </Form.Group>
                       
                    <center>  <Button variant="primary" className='col-lg-6' style={{ background: "rgb(13, 88, 100)" }} type="submit" onClick={() => sendUpdateRequest()}>
                           Update Details
                       </Button></center> 


                        </Form>
                         </div>
                    
                </section>
             
            </div>
            </div>
  )
}

export default EditStudentProfile;
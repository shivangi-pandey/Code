import React, { useState } from 'react'
import {Container, Form, Modal, Nav, NavDropdown,Button} from 'react-bootstrap'
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import { useLocalState } from '../../../util/useLocalStorage';
import StudentNavbar from '../StudentNavbar';
const UpdateStudentPassword = () => {

    const [jwt, setJwt] = useLocalState("", "jwt");
    const [userEmail, setUserEmail] = useLocalState("", "userEmail");

    const [password, setPassword] = useState("");
    const [passwordRe, setPasswordRe] = useState("");

    function sendUpdateRequest () {

        if(!(password === passwordRe)) {
            alert("Enter Same Password in both fields");
            return;
        }

        const reqBody = {
            "username" : userEmail,
            "password" : password,
        };

        fetch('/auth/updatePassword',{
            method:"POST",
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${jwt}`
            },
            body : JSON.stringify(reqBody)
        })
        .then((response) => {
          if (response.status === 200)
            return Promise.all([response.status, response.text()]);
            else return Promise.reject("Invalid Update Details attempt");
        })
        .then(([status, body]) => {
            alert(body);
            window.location.href = "/studentDashboard";
        })
        .catch((message) => {
          alert(message);
        });
    }
  return (
  
    <div style={{minHeight:"70vh"}}>
        <StudentNavbar />
        <div className="col-md-6 offset-md-3 border rounded p-4 mt-3 mb-5 shadow">
        
                <section className='d-flex justify-content-between'>
                    <div className="left_data mt-1 p-3" style={{ width: "100%" }}>
                    <center> <h2 className='text-center col-lg-6 mb-5 mt-2'>Change Password</h2>
</center>   
                        <Form>

                        <Form.Group as={Row} className="mb-3" controlId="formPlaintextPassword">
                            <Form.Label column sm="2">
                           Password
                            </Form.Label>
                            <Col sm="10">
                            <Form.Control 
                                type="password" 
                                placeholder="Password" 
                                value={password} 
                                onChange = {(e) => setPassword(e.target.value)} 
                            />
                            </Col>
                         </Form.Group>

                         <Form.Group as={Row} className="mb-4" controlId="formPlaintextPassword">
                            <Form.Label column sm="2">
                           Re-enter Password
                            </Form.Label>
                            <Col sm="10">
                            <Form.Control 
                                type="password" 
                                placeholder="Re-enter Password" 
                                value={passwordRe} 
                                onChange = {(e) => setPasswordRe(e.target.value)} 
                            />
                            </Col>
                         </Form.Group>
                       
                    <center>  
                    <Button id="sumbit" variant="primary" className='col-lg-6' style={{ background: "rgb(13, 88, 100)" }} type="button" onClick={() => sendUpdateRequest()}>
                           Update
                       </Button>
                    </center> 


                        </Form>
                         </div>
                    
                </section>
             
            </div>
            </div>
  )
}

export default UpdateStudentPassword;
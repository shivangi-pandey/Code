import React from 'react';
import HomeContent from './HomeContent';
import Pricing from './Pricing'
import StudentNavbar from './StudentNavbar';
import Studenthomepagefile from './Studenthomepagefile';
import Home from './HomeContent';


const StudentDashboard = () => {
  
  return (
    <React.Fragment>
      
      <StudentNavbar />
     <HomeContent/>
      <Pricing/>
    
    </React.Fragment>
  )
}

export default StudentDashboard;
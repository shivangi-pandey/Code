import React from 'react';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import './css/Style.css'

function StudentNavbar() {
  return (
    
     <Navbar collapseOnSelect expand="lg" style={{ background: "#37387a" }}>
      <Container fluid="xxl">
        <Navbar.Brand href="/studentDashboard"><p class="text-white">Hostel Availability Project</p></Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <div>
          <Nav className="ms-auto">
            <NavDropdown title={<span class="text-white">Profile</span>} id="basic-nav-dropdown">
              <NavDropdown.Item href="/Student/Editprofile">Edit Profile</NavDropdown.Item>
              <NavDropdown.Item href="/Student/UpdatePassword">
              Change Password
              </NavDropdown.Item>
            </NavDropdown>
            <Nav.Link href="/logout"><p class="text-white">Logout</p></Nav.Link>
          </Nav></div>
        </Navbar.Collapse>
      </Container>
    </Navbar> 


  



   
  )
}

export default StudentNavbar;




import { Container } from "react-bootstrap"
import React, { useState, useEffect } from "react";
import {useNavigate} from 'react-router-dom';
import { Link, NavLink } from 'react-router-dom'
import '../css/RoomPage.css';
import { useLocalState } from "../../../util/useLocalStorage";
import StudentNavbar from "../StudentNavbar";

const RoomPage = () => {
  const [buttonText, setButtonText] = useState('Request');

  const navigate = useNavigate();
  const [jwt, setJwt] = useLocalState("", "jwt");
  const [userEmail, setUserEmail] = useLocalState("", "userEmail");
  const [gender, setGender] = useLocalState("", "gender");
  const[rooms,setRooms]=useState([]);
  const [hasLoaded, setHasLoaded] = useState();
  const [hasHostelLoaded, setHasHostelLoaded] = useState();
  
  const[hostels,setHostels]=useState([]);
  useEffect(()=>{
      fetch(`/student/genderHostelView/${gender}`,{
        method:"GET",
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${jwt}`
        }, 
        })
        .then(response => Promise.all([response.json()]))
        .then(([body]) => {
          setHostels(body);
          setHasLoaded(true);
        });
  },[]);

  const[hostelId,setHostelId]=useState([]);
  let handleHostelSelectChange = (e) => {
    if (e.target.value !== "⬇️ Select a Hostel ⬇️") {
      fetch(`/student/viewRoomType/${e.target.value}`,{
        method:"GET",
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${jwt}`
          },
          })
          .then(res=>res.json())
          .then((result)=>{
            setRooms(result);
            setHostelId(e.target.value);
            setHasHostelLoaded(true);
            }
          )
    }
  }


function roomrequestfunc(roomTypeId){

      fetch(`/student/roomReq/${roomTypeId}?studentEmail=${userEmail}&hostelId=${hostelId}`,{
        method:"POST",
        headers:{'Authorization':`Bearer ${jwt}`
    }}
    )
    .then((response) => {
      if (response.status === 200)
        return Promise.all([response.status, response.text()]);
        else {
            return Promise.reject("Invalid Update Details attempt");
        }
    })
    .then(([status, body]) => {
        alert(body);
        window.location.href = "/studentDashboard";
    })
    .catch((message) => {
      alert(message);
    });
}

  return (
    hasLoaded
    ?
    <React.Fragment>
        <StudentNavbar/>
        <h3> 
          Select Hostel - 
          <select onClick={handleHostelSelectChange}> 
            <option value="⬇️ Select a Hostel ⬇️"> Select a Hostel </option>
              {hostels.map(hostel => (
                  <option key={hostel.hostelId} value= {hostel.hostelId}> 
                      Hostel Name - {hostel.hostelName}
                  </option>
              ))}
          </select>
        </h3>

        <div style={{minHeight:"70vh"}}>
    <Container>
    { hasHostelLoaded
    ?
    <div className="container">
    <h1 className="title">Types of Room Available</h1>
    <table>
      <thead>
      <tr>
              <th>Room Name </th>
              <th>Room Fee </th>
              <th>Room Capacity </th>
              <th>Book</th>
              
            </tr>
      </thead>
      <tbody>
                {rooms.map((getrooms) => (
                  <tr key={getrooms.roomTypeId}>
                     
                    <td>{getrooms.roomName}</td>
                    <td> {getrooms.roomFee}</td>
                    <td> {getrooms.roomCapacity}</td>
                    
                    <td><button className="btn btn-success" style={{textDecoration: "none",color:"white"}} onClick={()=>roomrequestfunc(getrooms.roomTypeId)}>
                      {buttonText}</button> </td>
                      <td></td>
                  </tr>
                ))}
              </tbody>
          
    </table>
  </div>  
  :
  <p> <b> Select a hostel to view Room Types </b> </p>  }
  
</Container>
</div>
</React.Fragment>
:
<p>Loading...</p>

    

 
  )
}

export default RoomPage;
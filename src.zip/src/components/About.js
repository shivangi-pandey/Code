import React from 'react'

const About = () => {
  return (
    <div>Welcome to the about page</div>
  )
}

export default About;
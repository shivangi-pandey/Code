import React from 'react';
import WardenHeader from '../../WardenHeader';
import { Container } from "react-bootstrap"
import '../../css/Style.css';
import { useState, useEffect, useMemo } from "react";
import Button from 'react-bootstrap/Button';
import { useLocalState } from '../../../../util/useLocalStorage';

const AllotRoomRequests = () => {

    const [jwt, setJwt] = useLocalState("", "jwt");
    const [hostelId, setHostelId] = useLocalState("", "hostelId");
    const[roomReqs,setRoomReqs]=useState([]);
    const [hasLoaded, setHasLoaded] = useState();

    useEffect(()=>{
        fetch(`/warden/viewAllotRoomReq/${hostelId}`,{
            method:"GET",
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${jwt}`
            }, 
            })
            .then(response => Promise.all([response.json()]))
            .then(([body]) => {
                setRoomReqs(body);
                setHasLoaded(true);
             });
            
    },[]);

    const allotRoom = (studentId) => {

      fetch(`/warden/allotRoom/${studentId}`,{
        method:"POST",
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${jwt}`
        }, 
        })
        .then(response => Promise.all([response.text()]))
        .then(([body]) => {
          alert(body);
          window.location.href = "/warden/allotRoomRequests";
         });
    }

    return (
        hasLoaded 
            ?
        <React.Fragment>
            <WardenHeader />
        
        <Container>
      <div className="row text-center">
        <div className="col-sm-8 text-success text-center">
        <h5 className="p-3 fw-bold text-black text-center">
            Allot Room Requests
          </h5>
        
          <table className="table table-bordered text-black text-center">
            <thead>
              <tr>   
                <th>Student Name</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
                {roomReqs.map((roomReq) => (
                  <tr key={roomReq.reqId}>
                    <td>{roomReq.student.studentName}</td>
                    <td>
                      <Button id="sumbit" variant="primary" className='col-lg-6' style={{ background: "rgb(13, 88, 100)" }} type="button" onClick={() => allotRoom(roomReq.student.studentId)}>
                           Allot Room
                       </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
          </table>
        </div>
      </div>      
    </Container>
  </React.Fragment>
  : 
  <p>Loading...</p>
    )
}

export default AllotRoomRequests;
import React from 'react';
import WardenHeader from '../../WardenHeader';
import { Container } from "react-bootstrap"
import '../../css/Style.css';
import { useState, useEffect, useMemo } from "react";
import Button from 'react-bootstrap/Button';
import { useLocalState } from '../../../../util/useLocalStorage';

const AllotRoom = () => {

    const [jwt, setJwt] = useLocalState("", "jwt");
    const[students,setStudents]=useState([]);
    const [hasLoaded, setHasLoaded] = useState();

    useEffect(()=>{
        fetch(`/warden/viewNonHostelStudents`,{
            method:"GET",
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${jwt}`
            }, 
            })
            .then(response => Promise.all([response.json()]))
            .then(([body]) => {
                setStudents(body);
                setHasLoaded(true);
             });
            
    },[]);

    const allotRoom = (studentId) => {

        fetch(`/warden/allotRoom/${studentId}`,{
          method:"POST",
          headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${jwt}`
          }, 
          })
          .then(response => Promise.all([response.text()]))
          .then(([body]) => {
            alert(body);
            window.location.href = "/warden/allotRoom";
           });
      }

    return (
        hasLoaded 
            ?
        <React.Fragment>
            <WardenHeader />
        
        <Container>
      <div className="row text-center">
        <div className="col-sm-8 text-success text-center">
        <h5 className="p-3 fw-bold text-black text-center">
            Students
          </h5>
        
          <table className="table table-bordered text-black text-center">
            <thead>
              <tr>   
                <th>Name</th>
                <th>Email</th>
                <th>Roll No</th>
                <th>Phone No</th>
                <th>Gender</th>
                <th>Course</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
                {students.map((student) => (
                  <tr key={student.studentId}>
                    <td>{student.studentName}</td>
                    <td>{student.email}</td>
                    <td>{student.studentRollNo}</td>
                    <td>{student.studentPhoneNo}</td>
                    <td>{student.studentGender}</td>
                    <td>{student.course.courseName}</td>
                    <td>
                      <Button id="sumbit" variant="primary" className='col-lg-6' style={{ background: "rgb(13, 88, 100)" }} type="button" onClick={() => allotRoom(student.studentId)}>
                           Allot Room
                       </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
          </table>
        </div>
      </div>      
    </Container>
  </React.Fragment>
  : 
  <p>Loading...</p>
    )
}

export default AllotRoom;
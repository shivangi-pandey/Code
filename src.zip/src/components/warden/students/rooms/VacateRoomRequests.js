import React from 'react';
import WardenHeader from '../../WardenHeader';
import { Container } from "react-bootstrap"
import '../../css/Style.css';
import { useState, useEffect, useMemo } from "react";
import Button from 'react-bootstrap/Button';
import { useLocalState } from '../../../../util/useLocalStorage';

const VacateRoomRequests = () => {

    const [jwt, setJwt] = useLocalState("", "jwt");
    const [hostelId, setHostelId] = useLocalState("", "hostelId");
    const[vacateReqs,setVacateReqs]=useState([]);
    const [hasLoaded, setHasLoaded] = useState();

    useEffect(()=>{
        fetch(`/warden/viewVacateRoomReq/${hostelId}`,{
            method:"GET",
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${jwt}`
            }, 
            })
            .then(response => Promise.all([response.json()]))
            .then(([body]) => {
                setVacateReqs(body);
                setHasLoaded(true);
             });
            
    },[]);

    const vacateRoom = (studentId) => {

      fetch(`/warden/vacateRoom/${studentId}`,{
        method:"DELETE",
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${jwt}`
        }, 
        })
        .then(response => Promise.all([response.text()]))
        .then(([body]) => {
          alert(body);
          window.location.href = "/warden/vacateRoomRequests";
         });
    }

    return (
        hasLoaded 
            ?
        <React.Fragment>
            <WardenHeader />
        
        <Container>
      <div className="row text-center">
        <div className="col-sm-8 text-success text-center">
        <h5 className="p-3 fw-bold text-black text-center">
            Vacate Room Requests
          </h5>
        
          <table className="table table-bordered text-black text-center">
            <thead>
              <tr>   
                <th>Student Name</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
                {vacateReqs.map((vacateReq) => (
                  <tr key={vacateReq.currentStatusId}>
                    <td>{vacateReq.student.studentName}</td>
                    <td>
                      <Button id="sumbit" variant="primary" className='col-lg-6' style={{ background: "rgb(13, 88, 100)" }} type="button" onClick={() => vacateRoom(vacateReq.student.studentId)}>
                           Vacate Room
                       </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
          </table>
        </div>
      </div>      
    </Container>
  </React.Fragment>
  : 
  <p>Loading...</p>
    )
}

export default VacateRoomRequests;
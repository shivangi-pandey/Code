import React from 'react'
import Header from './Header'




const AboutUs = () => {
    return (
        <React.Fragment>
            <Header/>
            <section className="content-container">
                <div className="textArea"> 
                    <h2>About Us</h2>
                    <p>   Welcome to Hostel Availability page!!!1 </p>

                    <p>
                    Welcome to Hostel Availability page!!!!!  </p>

                    <p>
                    Welcome to Hostel Availability page!!! Welcome to Hostel Availability page!!!1 Welcome to Hostel Availability page!!!1v  </p>

                    <p> Welcome to Hostel Availability page!!!1
                           Welcome to Hostel Availability page!!!1 
                           </p>
                                        <p>
                    Welcome to Hostel Availability page!!!1 </p>
                </div>
            </section>
            
        </React.Fragment>
    )
}

export default AboutUs;
import React from 'react'
import './shpf.css'
import user1 from '../../images/patrick.png';
import {useEffect,useState } from "react";
import { useLocalState } from '../../util/useLocalStorage';
import { Link } from "react-router-dom";
import Button from 'react-bootstrap/Button';
import './css/HomeContent.css';
import {useNavigate} from 'react-router-dom';

const Studenthomepagefile = () => {

    const [jwt, setJwt] = useLocalState("", "jwt");
    const [userEmail, setUserEmail] = useLocalState("", "userEmail");
    const [gender, setGender] = useLocalState("", "gender");
    const [hasLoaded, setHasLoaded] = useState();
    const[student,setStudent]=useState();
  
    const [hasNoHostel, setHasNoHostel] = useState();
    const [hasAllotRoomReq, setHasAllotRoomReq] = useState();
    const [hasHostel, setHasHostel] = useState();
    const [hasVacateHostelReq, setHasVacateHostelReq] = useState();
    
    useEffect(()=>{
      fetch(`/student/viewProfile/${userEmail}`,{
        method:"GET",
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${jwt}`
            },
            })
            .then(res=>res.json())
            .then((result)=>{
              setStudent(result);
              setGender(result.studentGender);
              fetch(`/student/assignedInfo/${result.studentId}`,{
                method:"GET",
                  headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${jwt}`
                    },
                    })
                    .then(re=> re.text())
                    .then((b)=>{
                      if(Object.keys(b).length === 0) setHasNoHostel(true);
                      else {
                        if (b.includes('"vacate_status":"R"')) setHasVacateHostelReq(true);
                        else setHasHostel(true);
                      }
                    }
                    )
  
                    fetch(`/student/viewRoomReq/${result.studentId}`,{
                      method:"GET",
                        headers: {
                          'Content-Type': 'application/json',
                          'Authorization': `Bearer ${jwt}`
                          },
                          })
                          .then(r=>r.text())
                          .then((b)=>{
                            if(b == "true") setHasAllotRoomReq(true);
                          }
                          )
              
              setHasLoaded(true);
              }
            )
  
      },[]);
  
      const navigate = useNavigate(); 
      const sendViewRoomRequest = () => {
        navigate("/Student/UserRoomdetails", {state:{id:student.studentId}});  
      }
  
  return (
    <div><div class="container-fluid">
    <div class="row no-gutter">
       
        <div class="col-md-6 d-none d-md-flex bg-image"></div>
        <div class="col-md-6 bg-light">
            <div class="login d-flex align-items-center py-5">

                
                <div class="container">
                    <div class="row">
                        <div class="col-lg-10 col-xl-7 mx-auto">
                        <div className="bg-container">
                    <h2>Welcome To Hostel Website</h2>
                    {!hasAllotRoomReq && hasNoHostel ? <Link className="grey" to="/student/roomPage"><button className="button">Book Hostel</button></Link> : <div> </div>}
                    {hasAllotRoomReq ? <p className="button"> <b>  Allot Room Request has been Submitted To Warden </b> </p> : <div> </div>}
                    {hasHostel ? 
                    <Button className="button" id="sumbit" variant="primary" type="button" onClick={() => sendViewRoomRequest()}>
                    View Room Details
                    </Button>
                    : 
                    <div> </div>}
                    {hasVacateHostelReq ? <p className="button"> <b> Vaccate Room Request has been Submitted To Warden </b> </p> : <div> </div>}
                </div>
                <section className="content-container">
                <div className="textArea"> 
                    <h2>{student.studentName}'s Profile</h2>
                   
                </div>
                <div className="col-md-6 offset-md-3 border rounded p-4 mt-3 mb-5 shadow">
                <div className="cust-container">
                    <img src={user1} alt="Avatar" style={{width:"90px"}}/>
                    <ul className="list-group list-group-flush">
                <li className="list-group-item mb-2">
                  <b>Name: </b>  {student.studentName}
                 
                </li>
                <li className="list-group-item mb-2">
                  <b>Email: </b>{student.email}
                 
                </li>
                <li className="list-group-item mb-2">
                  <b>Roll No: </b> {student.studentRollNo}
                
                </li>
                <li className="list-group-item mb-2">
                  <b>Phone No: </b> {student.studentPhoneNo}
                
                </li>
                <li className="list-group-item mb-2">
                  <b>Gender: </b> {student.studentGender}
                
                </li>
                <li className="list-group-item mb-2">
                  <b>Course Name: </b> {student.course.courseName}
                
                </li>
              </ul>
                </div>
                </div>
                
            </section>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div>
</div></div>
  )
}

export default Studenthomepagefile
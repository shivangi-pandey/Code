export const adminMenuItems = [
  {
    title: 'Home',
    url: '/admin/dashboard',
  },
  {
    title: 'Hostel',
    url: '/admin/hostel',
  },
  {
    title: 'Warden',
    url: '/admin/warden',
  },
  {
    title: 'Room',
    url: '/admin/room',
  },
  {
    title: 'Course',
    url: '/admin/course',
  },
  {
    title: 'Student',
    url: '/admin/student',
  },
];

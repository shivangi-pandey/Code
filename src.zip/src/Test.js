import React from 'react';
import HomeHeader from './components/Student/HomeHeader';


const Test = () => {
  
  return (
    <React.Fragment>
      
      <HomeHeader />
    
    </React.Fragment>
  )
}

export default TEst;
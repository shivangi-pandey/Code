import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import {
  BrowserRouter as Router,
  Routes,
  Route
} from "react-router-dom";
import PrivateRoute from './PrivateRoute';
import Home from './components/Home';
import Login from './components/Login';
import Logout from './components/Logout'
import About from './components/About.js';
import Signup from './components/Signup';
import Errror from './components/Student/Errror'
import Contact from './components/Contact';
import Footer from './components/Student/Footer'  
import AboutUs from './components/AboutUs';

import StudentDashboard from './components/Student/StudentDashboard';
import RoomPage from './components/Student/bookHostel/RoomPage';
import EditStudentProfile from './components/Student/profile/Editprofile';
import UpdateStudentPassword from './components/Student/profile/UpdatePassword';
import UserRoomdetails from './components/Student/vacateHostel/UserRoomdetails';

// import AdminDashboard from './components/admin/AdminDashboard';

import WardenDashboard from './components/warden/WardenDashboard';
import EditWardenProfile from './components/warden/profile/EditWardenProfile';
import UpdateWardenPassword from './components/warden/profile/UpdateWardenPassword';
import ViewRooms from './components/warden/hostel/rooms/ViewRooms';
import AddRoom from './components/warden/hostel/rooms/AddRoom';
import EditRoom from './components/warden/hostel/rooms/EditRoom';
import ViewRoomTypes from './components/warden/hostel/roomTypes/ViewRoomTypes';
import AddRoomType from './components/warden/hostel/roomTypes/AddRoomType';
import EditRoomType from './components/warden/hostel/roomTypes/EditRoomType';
import ViewStudentRecords from './components/warden/students/records/ViewStudentRecords';
import AllotRoomRequests from './components/warden/students/rooms/AllotRoomRequests';
import AllotRoom from './components/warden/students/rooms/AllotRoom';
import VacateRoomRequests from './components/warden/students/rooms/VacateRoomRequests';
import VacateRoom from './components/warden/students/rooms/VacateRoom';
import AdminDashboard from './components/admin/dashboard/AdminDashboard';
import AdminHostel from './components/admin/hostel/AdminHostel';

function App() {

  return (
  <div>
    <Routes>
      <Route path='/' element={<Home />} />
      <Route path='/AboutUs' element={<AboutUs/>} />
      <Route path='/contact' element={<Contact/>} />
      <Route path='/Signup' element={<Signup/>} />
      <Route path='/login' element={<Login />} />
      <Route path='/logout' element={<Logout />} />
      <Route path='/about' element={<About />} />
      <Route path='*' element={<Errror />} />

      
      {/* <Route path='/admin/adminDashboard' element={<PrivateRoute><AdminDashboard /></PrivateRoute>}/> */}

      <Route path='/studentDashboard' element={<PrivateRoute><StudentDashboard/></PrivateRoute>}/>
      <Route path='/Student/Editprofile' element={<PrivateRoute><EditStudentProfile /></PrivateRoute>} />
      <Route path='/Student/UpdatePassword' element={<PrivateRoute><UpdateStudentPassword/></PrivateRoute>}/>
      <Route path='/student/roomPage' element={<PrivateRoute><RoomPage/></PrivateRoute>}/>
      <Route path='/Student/UserRoomdetails' element={<PrivateRoute><UserRoomdetails/></PrivateRoute>}/>
      
       <Route path='/wardenDashboard' element={
      <PrivateRoute>
        <WardenDashboard />
        </PrivateRoute>
      }
       />
       <Route path='/warden/editProfile' element={
      <PrivateRoute>
        <EditWardenProfile />
        </PrivateRoute>
      }
       />
       <Route path='/warden/updatePassword' element={
      <PrivateRoute>
        <UpdateWardenPassword />
        </PrivateRoute>
      }
       />
       <Route path='/warden/viewRooms' element={
      <PrivateRoute>
        <ViewRooms />
        </PrivateRoute>
      }
       />
       <Route path='/warden/addRoom' element={
      <PrivateRoute>
        <AddRoom />
        </PrivateRoute>
      }
       />
       <Route path='/warden/editRoom' element={
      <PrivateRoute>
        <EditRoom />
        </PrivateRoute>
      }
       />
       <Route path='/warden/viewRoomTypes' element={
      <PrivateRoute>
        <ViewRoomTypes />
        </PrivateRoute>
      }
       />
       <Route path='/warden/addRoomType' element={
      <PrivateRoute>
        <AddRoomType />
        </PrivateRoute>
      }
       />
        <Route path='/warden/editRoomType' element={
      <PrivateRoute>
        <EditRoomType />
        </PrivateRoute>
      }
       />
       <Route path='/warden/viewStudentRecords' element={
      <PrivateRoute>
        <ViewStudentRecords />
        </PrivateRoute>
      }
       />
       <Route path='/warden/allotRoomRequests' element={
      <PrivateRoute>
        <AllotRoomRequests />
        </PrivateRoute>
      }
       />
       <Route path='/warden/allotRoom' element={
      <PrivateRoute>
        <AllotRoom />
        </PrivateRoute>
      }
       />
       <Route path='/warden/vacateRoomRequests' element={
      <PrivateRoute>
        <VacateRoomRequests />
        </PrivateRoute>
      }
       />
       <Route path='/warden/vacateRoom' element={
      <PrivateRoute>
        <VacateRoom />
        </PrivateRoute>
      }
       />
          {/* TODO: Remove private route comments */}
          <Route
            path='/admin/dashboard'
            element={
              // <PrivateRoute>
              <AdminDashboard />
              // </PrivateRoute>
            }
          />
          <Route
            path='/admin/hostel'
            element={
              // <PrivateRoute>
              <AdminHostel />
              // </PrivateRoute>
            }
          />

    </Routes>
    <Footer/>
    </div>
   
    
  );
}

export default App;

